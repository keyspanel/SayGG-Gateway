import 'dotenv/config';

const config = {
  database: {
    url: process.env.DATABASE_URL || '',
  },
  auth: {
    jwtSecret: (() => {
      const s = process.env.JWT_SECRET;
      if (!s) {
        throw new Error('[gateway] JWT_SECRET env var is required. Refusing to start with an insecure default.');
      }
      return s;
    })(),
  },
  port: parseInt(process.env.PG_PORT || '5000', 10),
};

export default config;
